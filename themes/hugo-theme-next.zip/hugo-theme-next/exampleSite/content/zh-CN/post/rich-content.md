+++
author = "Hugo Authors"
title = "富文本内容测试"
date = "2019-03-10"
description = "A brief description of Hugo Shortcodes"
tags = [
    "shortcodes",
    "privacy",
]
+++

Hugo 上有几个[**内置短码**](https://gohugo.io/content-management/shortcodes/#use-hugos)，用于丰富内容，以及[**隐私配置**](https://gohugo.io/about/hugo-and-gdpr/)还有一组简单的短代码，支持各种社交媒体嵌入的静态和非 JS 版本。

<!--more-->

## YouTube 增强隐私短码

{{/*< youtube ZJthWmvUzzc >*/}}

<br>

---

## Twitter 短码

{{/*< twitter_simple 1085870671291310081 >*/}}

<br>

---

## Vimeo 短码

{{/*< vimeo_simple 48912912 >*/}}

---

## 哔哩哔哩短码

{{<  bilibili BV1m4411c7ia >}}